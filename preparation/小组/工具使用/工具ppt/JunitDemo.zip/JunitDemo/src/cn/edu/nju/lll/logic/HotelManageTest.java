package cn.edu.nju.lll.logic;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class HotelManageTest {
	
	private HotelManage manage;
	Hotel h1;
    Hotel h2;
    Hotel h3;
	
	@Before
	public void setUp(){
		h1 = new Hotel("Hanting",10,20);
        h2 = new Hotel("LvZhou",90,20);
        h3 = new Hotel("RuJia",30,10);
	}	

	@Test
	public void testSortHotelByName() {
        manage = new HotelManage();
        manage.addHotel(h3);
        manage.addHotel(h1);
        manage.addHotel(h2);
        
        manage.sortHotelByName(false);  
        List<Hotel> list = manage.getHotelList();
        assertEquals(list.get(0),h1);
        assertEquals(list.get(1),h2);
        assertEquals(list.get(2),h3);
        
        manage.sortHotelByName(true);
        list = manage.getHotelList();
        assertEquals(list.get(0),h3);
        assertEquals(list.get(1),h2);
        assertEquals(list.get(2),h1);
	}
	
	@Test
	public void testGetHotelNum(){
		manage = new HotelManage();
		assertEquals(0,manage.getHotelNum());
		manage.addHotel(h1);
		assertEquals(1,manage.getHotelNum());
		manage.addHotel(h2);
		assertEquals(2,manage.getHotelNum());
		manage.addHotel(h3);
		assertEquals(3,manage.getHotelNum());
	}

}
