package cn.edu.nju.lll.logic;

import java.util.ArrayList;
import java.util.List;

public class HotelManage {
    private List<Hotel> hotelList;

    public HotelManage(){
        hotelList = new ArrayList<Hotel>();
    }

    public int getHotelNum(){
        return hotelList.size();
    }

    public void addHotel(Hotel hotel){
        hotelList.add(hotel);
    }

    public List<Hotel> getHotelList(){
        return hotelList;
    }

    public void sortHotelByName(boolean isInverted){
        if(isInverted){
            hotelList.sort((Hotel h1,Hotel h2) -> h2.getName().compareTo(h1.getName()));
        } else {
            hotelList.sort((Hotel h1,Hotel h2) -> h1.getName().compareTo(h2.getName()));
        }
    }

}
