package cn.edu.nju.lll.logic;


public class Hotel {
    private String name;
    private int bigRoomNumber;
    private int smallRoomNumber;

    public Hotel(String name,int bigNum,int smallNum){
        this.name = name;
        this.bigRoomNumber = bigNum;
        this.smallRoomNumber = smallNum;
    }

    public void setName(String name){
        this.name = name;
    }

    public String getName(){
        return name;
    }

    public void setBigRoomNumber(int num){
        this.bigRoomNumber = num;
    }

    public int getBigRoomNumber(){
        return bigRoomNumber;
    }

    public void setSmallRoomNumber(int num){
        this.smallRoomNumber = num;
    }

    public int getSmallRoomNumber(){
        return smallRoomNumber;
    }

    public String toString(){
        return name + " has "+bigRoomNumber+" big rooms," + smallRoomNumber+" small rooms.";
    }
}
