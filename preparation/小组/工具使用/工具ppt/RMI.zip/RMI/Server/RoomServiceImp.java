import java.rmi.RemoteException;

public class RoomServiceImp extends java.rmi.server.UnicastRemoteObject implements RoomService {

    private static final long serialVersionUID = 3434060152387200042L;

    public RoomServiceImp() throws RemoteException {
        super();
    }

    @Override
    public String bookRoom(String name,String hotel) throws RemoteException {
        if(name != null && hotel != null){
        	return name +"住在"+hotel;
        } else {
        	return "missing message";
        }
    }

    @Override
    public String checkOut(String name,String hotel) throws RemoteException {
    	if(name != null && hotel != null){
    		return name +"离开"+hotel;
    	} else {
    		return "missing message";
    	}
    }

}