
import java.rmi.RemoteException;

public interface RoomService extends java.rmi.Remote {

    String bookRoom(String name,String hotel) throws RemoteException;

    String checkOut(String name,String hotel) throws RemoteException;

}