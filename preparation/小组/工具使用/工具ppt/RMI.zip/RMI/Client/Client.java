import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class Client {

    public static void main(String[] args) {
        try {
            RoomService roomService = (RoomService) Naming.lookup("rmi://172.17.232.191:1098/RoomService");
            System.out.println(roomService.bookRoom("陆一飞","汉庭"));
            System.out.println(roomService.checkOut("陆一飞","汉庭"));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (NotBoundException e) {
            e.printStackTrace();
        }
    }

}